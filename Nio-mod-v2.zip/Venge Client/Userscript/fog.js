function updateVisuals() {
  if (pc.currentMap === "Sierra") {
    // Remove fog
    pc.app.scene.fogDensity = 0;

    // Some other visual improvements
    /*pc.app.renderer.scene.skyboxIntensity = 3;
    pc.app.scene.exposure = 1;
    pc.app.scene.toneMapping = pc.TONEMAP_NEUTRAL;
    pc.app.scene.gammaCorrection = 5;
    pc.app.root.findByName("Light").light.color = {
      r: 1.3,
      g: 1.1,
      b: 1.1,
      a: 1,
    };*/
  }
}

// Add Map:Loaded event listener
pc.app.on("Map:Loaded", () => {
  setTimeout(updateVisuals, 500);
});

// Add Player:Respawn event listener
pc.app.on("Player:Respawn", () => {
  setTimeout(updateVisuals, 500);
});